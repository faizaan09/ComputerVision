#ifndef HEADER_H
#define HEADER_H

#include <iostream>
#include <math.h>

#include <opencv.hpp>
#include <highgui.hpp>
#include <core.hpp>
#include <features2d.hpp>
#include <xfeatures2d.hpp>

#endif // !HEADER_H
